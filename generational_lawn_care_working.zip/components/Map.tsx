
import React from 'react';
export default function Map() {
  return (
    <div className="w-full h-96 bg-gray-300 text-center flex items-center justify-center">
      <p>Interactive Toronto/GTA Service Area Map Placeholder</p>
    </div>
  );
}
